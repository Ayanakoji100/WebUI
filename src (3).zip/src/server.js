const express = require('express');
const session = require('express-session');
const app = express();
const path = require('path');
const cors = require('cors');
const multer = require('multer');
const { MongoClient } = require('mongodb');

// MongoDB setup
const url = 'mongodb://localhost:27017';
const client = new MongoClient(url);
const dbName = 'packrush';

async function connect() {
  try {
    await client.connect();
    console.log('Connected to MongoDB server');
  } catch (err) {
    console.error('Error connecting to MongoDB server', err);
    process.exit(1);
  }
}
connect();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join('C:', 'Sem 6', '19CS694-Web User Interface Design', 'packrush-new', 'public', 'img'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Only image files are allowed'), false);
    }
    cb(null, true);
  },
  limits: { fileSize: 5 * 1024 * 1024 }
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({
  origin: 'http://localhost:4200',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use((req, res, next) => {
  const host = req.headers.host || req.headers.origin || '';
  const blockedDomains = ['git.new'];
  if (blockedDomains.some(domain => host.includes(domain))) {
    return res.status(403).json({ success: false, message: 'Access denied' });
  }
  if (req.url.includes('://') || req.url.includes('git.new')) {
    return res.status(400).json({ success: false, message: 'Invalid URL' });
  }
  next();
});

// Serve static files for images
const imagePath = path.join('C:', 'Sem 6', '19CS694-Web User Interface Design', 'packrush-new', 'public', 'img');
app.use('/images', express.static(imagePath, {
  setHeaders: (res) => {
    res.set('Content-Type', 'image/*');
  }
}), (req, res) => {
  res.status(404).json({ success: false, message: 'Image not found' });
});

app.use(session({
  secret: process.env.SESSION_SECRET || 'your_secret_key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, httpOnly: true, sameSite: 'lax' }
}));

// Multer error handling middleware
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ success: false, message: 'File size exceeds 5MB limit' });
    }
    return res.status(400).json({ success: false, message: `File upload error: ${err.message}` });
  } else if (err.message === 'Only image files are allowed') {
    return res.status(400).json({ success: false, message: err.message });
  }
  next(err);
});

// Routes
app.get('/api/products', async (req, res) => {
  try {
    const db = client.db(dbName);
    const products = await db.collection('products').find({}).toArray();
    const response = products.map(product => ({
      product_id: product.product_id || '',
      product_name: product.product_name || 'Unknown',
      product_category: product.product_category || 'Uncategorized',
      Price: product.Price || 0,
      Image: product.Image ? `http://localhost:5000/images/${product.Image}` : `http://localhost:5000/images/default.jpg`
    }));
    res.json(response);
  } catch (err) {
    console.error('Error fetching products:', err.message);
    res.status(500).json({ success: false, message: 'Error fetching products' });
  }
});

app.get('/api/products/category/:category', async (req, res) => {
  try {
    const category = req.params.category.toLowerCase();
    const db = client.db(dbName);
    const products = await db.collection(category).find({}).toArray();
    const response = products.map(product => ({
      product_id: product.product_id || '',
      product_name: product.product_name || 'Unknown',
      product_category: product.product_category || category.charAt(0).toUpperCase() + category.slice(1),
      Price: product.Price || 0,
      Image: product.Image ? `http://localhost:5000/images/${product.Image}` : `http://localhost:5000/images/default.jpg`
    }));
    res.json(response);
  } catch (err) {
    console.error('Error fetching products by category:', err.message);
    res.status(500).json({ success: false, message: 'Error fetching products by category' });
  }
});

app.post('/api/products', upload.single('Image'), async (req, res) => {
  try {
    const db = client.db(dbName);
    const product = {
      product_id: req.body.product_id,
      product_name: req.body.product_name,
      product_category: req.body.product_category,
      Price: parseFloat(req.body.Price),
      Image: req.file ? req.file.filename : req.body.Image || ''
    };
    if (!product.product_category) {
      return res.status(400).json({ success: false, message: 'product category is required' });
    }
    if (!product.Image) {
      return res.status(400).json({ success: false, message: 'Image is required' });
    }
    const categoryCollection = product.product_category.toLowerCase();

    await db.collection('products').insertOne(product);
    await db.collection(categoryCollection).insertOne(product);

    res.status(201).send();
  } catch (err) {
    console.error('Error adding product:', err);
    res.status(500).json({ success: false, message: 'Error adding product' });
  }
});

app.put('/api/products/:id', upload.single('Image'), async (req, res) => {
  try {
    const db = client.db(dbName);
    const product = await db.collection('products').findOne({ product_id: req.params.id });
    if (!product) {
      return res.status(404).json({ success: false, message: 'product not found' });
    }
    const categoryCollection = product.product_category.toLowerCase();

    const updateData = {
      product_id: req.body.product_id || product.product_id,
      product_name: req.body.product_name || product.product_name,
      product_category: req.body.product_category || product.product_category,
      Price: req.body.Price ? parseFloat(req.body.Price) : product.Price,
      Image: req.file ? req.file.filename : (product.Image || req.body.Image)
    };

    await db.collection('products').updateOne({ product_id: req.params.id }, { $set: updateData });
    await db.collection(categoryCollection).updateOne({ product_id: req.params.id }, { $set: updateData });

    res.status(200).send();
  } catch (err) {
    console.error('Error updating product:', err);
    res.status(500).json({ success: false, message: 'Error updating product' });
  }
});

app.delete('/api/products/:id', async (req, res) => {
  try {
    const db = client.db(dbName);
    const product = await db.collection('products').findOne({ product_id: req.params.id });
    if (!product) {
      return res.status(404).json({ success: false, message: 'product not found' });
    }
    const categoryCollection = product.product_category.toLowerCase();

    await db.collection('products').deleteOne({ product_id: req.params.id });
    await db.collection(categoryCollection).deleteOne({ product_id: req.params.id });

    res.status(200).send();
  } catch (err) {
    console.error('Error deleting product:', err);
    res.status(500).json({ success: false, message: 'Error deleting product' });
  }
});

app.get('/api/admin/orders', async (req, res) => {
  try {
    const db = client.db(dbName);
    const orders = await db.collection('orders').find({}).toArray();
    res.json(orders);
  } catch (err) {
    console.error('Error fetching orders:', err);
    res.status(500).json({ success: false, message: 'Error fetching orders' });
  }
});

app.get('/api/customer_reviews', async (req, res) => {
  try {
    const db = client.db(dbName);
    const contacts = await db.collection('contacts').find({}).toArray();
    const response = contacts.map(contact => ({
      _id: contact._id || '',
      customer: contact.name || 'N/A',
      phone: contact.phone || 'No phone number',
      subject : contact.subject || 'No Subject',
      comment: contact.message || 'No comment'
    }));
    res.json(response);
  } catch (err) {
    console.error('Error fetching reviews:', err.message);
    res.status(500).json({ success: false, message: 'Error fetching reviews' });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required' });
  }
  try {
    const db = client.db(dbName);
    const user = await db.collection('register').findOne({ email });
    if (user && user.password === password) {
      req.session.user = { email };
      res.json({ success: true, message: 'Login successful', redirectUrl: '/index' });
    } else {
      res.status(401).json({ success: false, message: 'Invalid email or password' });
    }
  } catch (err) {
    console.error('Error during login:', err);
    res.status(500).json({ success: false, message: 'Error processing login' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Error destroying session:', err);
      return res.status(500).json({ success: false, message: 'Error logging out' });
    }
    res.json({ success: true, message: 'Logged out successfully' });
  });
});

app.post('/api/signup', async (req, res) => {
  const { name, email, phone_no, password } = req.body;
  if (!name || !email || !phone_no || !password) {
    return res.status(400).json({ success: false, message: 'All fields are required' });
  }
  try {
    const db = client.db(dbName);
    const collection = db.collection('register');
    const existingUser = await collection.findOne({ $or: [{ email }, { phone_no }] });
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'Email or phone number already registered' });
    }
    const result = await collection.insertOne({ name, email, phone_no, password });
    res.json({
      success: result.acknowledged,
      message: result.acknowledged ? 'Signup successful' : 'Account creation failed',
      redirectUrl: '/'
    });
  } catch (err) {
    console.error('Error during signup:', err);
    res.status(500).json({ success: false, message: 'Error inserting document' });
  }
});

app.post('/api/contact', async (req, res) => {
  const { name, email, phone, subject, message } = req.body;
  if (!name || !email || !phone || !subject || !message) {
    return res.status(400).json({ success: false, message: 'All fields are required' });
  }
  try {
    const db = client.db(dbName);
    const users = db.collection('register');
    const contacts = db.collection('contacts');
    const normalizedPhone = phone.replace(/\D/g, '');
    const user = await users.findOne({ email, phone_no: normalizedPhone });
    if (!user) {
      return res.status(400).json({ success: false, message: 'Please check your email and phone number.' });
    }
    await contacts.insertOne({ name, email, phone, subject, message });
    res.json({ success: true, message: `Thank you for contacting us, ${name}!` });
  } catch (err) {
    console.error('Error saving contact:', err);
    res.status(500).json({ success: false, message: 'Error saving contact' });
  }
});

app.get('/api/user', async (req, res) => {
  if (!req.session.user || !req.session.user.email) {
    return res.status(401).json({ success: false, message: 'Session expired. Please log in again.' });
  }
  try {
    const db = client.db(dbName);
    const user = await db.collection('register').findOne({ email: req.session.user.email });
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({
      success: true,
      name: user.name,
      email: user.email,
      phone_no: user.phone_no
    });
  } catch (err) {
    console.error('Error fetching user details:', err);
    res.status(500).json({ success: false, message: 'Error fetching user details' });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const order = req.body;
    if (!order.items || !Array.isArray(order.items) || order.items.length === 0) {
      return res.status(400).json({ success: false, message: 'Order must include at least one item' });
    }
    if (!order.deliveryDetails || !order.deliveryDetails.fullName || !order.deliveryDetails.phoneNumber || !order.deliveryDetails.email || !order.deliveryDetails.address) {
      return res.status(400).json({ success: false, message: 'Complete delivery details are required' });
    }
    if (typeof order.total !== 'number' || order.total <= 0) {
      return res.status(400).json({ success: false, message: 'Invalid total amount' });
    }
    if (!req.session.user || !req.session.user.email) {
      return res.status(401).json({ success: false, message: 'Session expired. Please log in again.' });
    }
    const db = client.db(dbName);
    const result = await db.collection('orders').insertOne({
      ...order,
      userEmail: req.session.user.email,
      createdAt: new Date()
    });
    res.json({
      success: true,
      message: 'Order placed successfully',
      orderId: result.insertedId
    });
  } catch (err) {
    console.error('Error saving order:', err);
    res.status(500).json({ success: false, message: 'Error saving order' });
  }
});

app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Endpoint not found' });
});

app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

process.on('SIGTERM', async () => {
  console.log('SIGTERM received. Closing MongoDB connection...');
  await client.close();
  process.exit(0);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});