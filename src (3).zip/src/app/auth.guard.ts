import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    this.authService.refreshUser(); // Ensure user state is up-to-date
    if (!this.authService.isLoggedIn()) {
      this.router.navigate(['/']); // Not logged in, redirect to login
      return false;
    }

    const requiredRole = route.data['role'];
    if (requiredRole) {
      const userRole = this.authService.getUserRole();
      if (userRole !== requiredRole) {
        this.router.navigate(['/index']); // Role mismatch, redirect to index
        return false;
      }
    }

    return true; // Allow access
  }
}