import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductItem, ProductService } from '../product.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-category',
  standalone: false,
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  showCart: boolean = false;
  cart: ProductItem[] = [];
  categoryMenu: ProductItem[] = [];
  categoryName: string = '';

  constructor(
    private route: ActivatedRoute,
    private ProductService: ProductService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadCart();
    this.route.paramMap.subscribe(params => {
      this.categoryName = params.get('category') || '';
      this.loadCategoryMenu();
    });
  }

  logout() {
    this.authService.logout();
  }

  loadCategoryMenu(): void {
    if (this.categoryName) {
      this.ProductService.getproductItemsByCategory(this.categoryName.toLowerCase()).subscribe({
        next: (products: ProductItem[]) => {
          this.categoryMenu = products.map((product: ProductItem) => ({
            product_id: product.product_id || '',
            product_name: product.product_name || 'Unknown',
            Price: product.Price || 0,
            Image: product.Image || 'http://localhost:5000/images/default.jpg',
            quantity: product.quantity || 1
          }));
        },
        error: (err: any) => {
          console.error(`Error fetching ${this.categoryName} menu:`, err);
          this.categoryMenu = [];
        }
      });
    }
  }

  addToCart(product: ProductItem): void {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    let existing = cart.find((item: ProductItem) => item.product_id === product.product_id);
    if (existing) {
      existing.quantity = (existing.quantity || 0) + (product.quantity || 1);
    } else {
      cart.push({ ...product, quantity: product.quantity || 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    this.loadCart();
    product.quantity = 1;
  }

  toggleCart(): void {
    this.showCart = !this.showCart;
  }

  loadCart(): void {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
  }

  removeFromCart(item: ProductItem): void {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
    const index = cart.findIndex((i: ProductItem) => i.product_id === item.product_id);
    if (index !== -1) {
      cart.splice(index, 1);
      localStorage.setItem('cart', JSON.stringify(cart));
      this.loadCart();
    }
  }

  getCartTotal(): number {
    return this.cart.reduce((sum, item) => sum + (item.Price || 0) * (item.quantity || 1), 0);
  }

  scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}