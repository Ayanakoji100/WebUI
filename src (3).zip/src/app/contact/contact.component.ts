import { Component, OnInit } from '@angular/core';
import { ContactService, ContactResponse } from '../contact.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { productService, productItem } from '../product.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-contact',
  standalone: false,
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  formData = {
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  };
  successMessage: string = '';
  errorMessage: string = '';
  showCart: boolean = false;
  cart: productItem[] = [];

  constructor(
    private contactService: ContactService,
    private router: Router,
    private productService: productService, // Added for potential future use, though not directly used here
    private authservice: AuthService
  ) {}

  ngOnInit(): void {
    this.loadCart();
  }

  logout(){
    this.authservice.logout();
  }

  toggleCart(): void {
    this.showCart = !this.showCart;
  }

  loadCart(): void {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
  }

  removeFromCart(item: productItem): void {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
    const index = cart.findIndex((i: productItem) => i.product_id === item.product_id);
    if (index !== -1) {
      cart.splice(index, 1);
      localStorage.setItem('cart', JSON.stringify(cart));
      this.loadCart();
    }
  }

  getCartTotal(): number {
    return this.cart.reduce((sum, item) => sum + (item.Price || 0) * (item.quantity || 1), 0);
  }

  onSubmit(form: NgForm): void {
    if (form.valid) {
      this.contactService.sendContactForm(
        this.formData.name,
        this.formData.email,
        this.formData.phone,
        this.formData.subject,
        this.formData.message
      ).subscribe({
        next: (response: ContactResponse) => {
          if (response.success) {
            this.successMessage = response.message;
            this.errorMessage = '';
            form.resetForm();
            setTimeout(() => {
              this.router.navigateByUrl(response.redirect || '/index');
            }, 2000);
          } else {
            this.errorMessage = response.message || 'Failed to send message';
            this.successMessage = '';
          }
        },
        error: (err) => {
          console.error('Contact form error:', err);
          this.errorMessage = 'An error occurred while sending the message. Please try again.';
          this.successMessage = '';
        }
      });
    } else {
      this.errorMessage = 'Please fill in all required fields correctly';
      this.successMessage = '';
    }
  }
}