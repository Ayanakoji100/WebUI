import { Component, OnInit } from '@angular/core';
import { AdminService, productItem } from '../admin.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-delete-product',
  standalone: false,
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.css']
})
export class DeleteproductComponent implements OnInit {
  productItems: productItem[] = [];
  categoryproducts: productItem[] = []; // products filtered by category
  successMessage: string = '';
  errorMessage: string = '';
  categories: string[] = ['Flower Pots', 'Gift Boxes', 'Repeated Shots', 'Set out & Gun Out', 'Sound Crackers', 'Sparklers', 'Twinkling Star & Pencil', 'Whistling Novalties', 'Bijili'];
  selectedCategory: string = ''; // Selected category

  constructor(private adminService: AdminService, private authservice:AuthService) {}

  logout(){
    this.authservice.logout();
  }
  ngOnInit(): void {
    this.loadproductItems();
  }

  loadproductItems(): void {
    this.adminService.getproductItems().subscribe(items => {
      this.productItems = items;
      this.loadCategoryproducts(); // Load initial category products
    });
  }

  loadCategoryproducts(): void {
    if (this.selectedCategory) {
      this.adminService.getproductItemsByCategory(this.selectedCategory.toLowerCase()).subscribe(products => {
        this.categoryproducts = products;
      }, err => {
        this.errorMessage = 'Error loading category products: ' + err.message;
        this.categoryproducts = [];
      });
    } else {
      this.categoryproducts = [];
    }
  }

  deleteproduct(id: string): void {
    if (confirm('Are you sure you want to delete this product item?')) {
      this.adminService.deleteproductItem(id).subscribe({
        next: () => {
          this.successMessage = 'product item deleted successfully!';
          this.errorMessage = '';
          this.loadCategoryproducts(); // Refresh the list
        },
        error: (err) => {
          console.error('Delete product error:', err);
          this.errorMessage = 'Failed to delete product item. Please try again.';
          this.successMessage = '';
        }
      });
    }
  }
}