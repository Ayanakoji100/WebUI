import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService, ProductItem } from '../product.service';
import { AuthService } from '../auth.service'; // ⬅️ Import AuthService

interface Category {
  name: string;
  image: string;
}

@Component({
  selector: 'app-index',
  standalone: false,
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
  searchTerm: string = '';
  showCart: boolean = false;
  cart: ProductItem[] = [];
  products: ProductItem[] = [];
  categories: Category[] = [
    { name: 'Flower Pots', image: '/img/category/ashoka_0x300.jpg' },
    { name: 'Whistling Novalties', image: '/img/category/siren7_0x300.jpg' },
    { name: 'Twinkling Star & Pencil', image: '/img/category/lala_0x300.jpg' },
    { name: 'Sparklers', image: '/img/category/10cm_color7_0x300.jpg' },
    { name: 'Sound Crackers', image: '/img/category/kungfu6_0x300.jpg' },
    { name: 'Set out & Gun Out', image: '/img/category/digital_gunout_0x300.jpg' },
    { name: 'Rockets', image: '/img/category/musical-rocket43_0x300.jpg' },
    { name: 'Repeated Shots', image: '/img/category/musical-rocket43_0x300.jpg' },
    { name: 'Gift Boxes', image: '/img/category/40_items1_0x300.jpg' }
  ];

  constructor(
    private productService: ProductService,
    private router: Router,
    private authService: AuthService // ⬅️ Inject AuthService
  ) {}

  ngOnInit(): void {
    this.loadCart();
  }

  onSearch(): void {
    if (this.searchTerm.trim()) {
      this.router.navigate(['/product-search'], { queryParams: { search: this.searchTerm } });
    }
  }

  addToCart(product: ProductItem): void {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    let existing = cart.find((item: ProductItem) => item.product_id === product.product_id);
    if (existing) {
      existing.quantity = (existing.quantity || 0) + (product.quantity || 1);
    } else {
      cart.push({ ...product, quantity: product.quantity || 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    this.loadCart();
    alert(`${product.product_name || 'Unknown'} added to cart!`);
    product.quantity = 1;
  }

  toggleCart(): void {
    this.showCart = !this.showCart;
  }

  loadCart(): void {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
  }

  removeFromCart(item: ProductItem): void {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
    const index = cart.findIndex((i: ProductItem) => i.product_id === item.product_id);
    if (index !== -1) {
      cart.splice(index, 1);
      localStorage.setItem('cart', JSON.stringify(cart));
      this.loadCart();
    }
  }

  getCartTotal(): number {
    return this.cart.reduce((sum, item) => sum + (item.Price || 0) * (item.quantity || 1), 0);
  }

  scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  getCategoryRoute(categoryName: string): string {
    const routes: { [key: string]: string } = {
      'Flower Pots': '/Flower Pots',
      'Whistling Novalties': '/category/Whistling Novalties',
      'Twinkling Star & Pencil': '/category/Twinkling Star & Pencil',
      'Sparklers': '/category/Sparklers',
      'Sound Crackers': '/category/Sound Crackers',
      'Set out & Gun Out': '/category/Set out & Gun Out',
      'Rockets': '/category/Rockets',
      'Repeated Shots': '/category/Repeated Shots',
      'Gift Boxes': '/category/Gift Boxes'
    };
    return routes[categoryName] || '/products';
  }

  logout(): void {
    this.authService.logout();
  }
}