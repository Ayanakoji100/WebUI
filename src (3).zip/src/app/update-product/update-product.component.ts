import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-update-product',
  standalone: false,
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateproductComponent {
  productItems: any[] = [];
  categoryproducts: any[] = []; // products filtered by category
  selectedproduct: any = null;
  successMessage: string | null = null;
  errorMessage: string | null = null;
  categories = ['Flower Pots', 'Gift Boxes', 'Repeated Shots', 'Set out & Gun Out', 'Sound Crackers', 'Sparklers', 'Twinkling Star & Pencil', 'Whistling Novalties', 'Bijili'];
  selectedCategory: string = ''; // Selected category
  newImage: File | null = null; // Store the new image file
  previewImage: string | null = null; // Store the preview URL for the new image

  constructor(private http: HttpClient, private authservice: AuthService) {
    this.loadproductItems();
  }

  logout(){
    this.authservice.logout();
  }
  loadproductItems() {
    this.http.get('http://localhost:5000/api/products', { withCredentials: true }).subscribe({
      next: (data: any) => {
        this.productItems = data;
        this.loadCategoryproducts(); // Load initial category products
      },
      error: (err) => {
        this.errorMessage = 'Error loading product items: ' + err.message;
      }
    });
  }

  loadCategoryproducts() {
    if (this.selectedCategory) {
      this.http.get(`http://localhost:5000/api/products/category/${this.selectedCategory.toLowerCase()}`, { withCredentials: true }).subscribe({
        next: (data: any) => {
          this.categoryproducts = data;
          this.selectedproduct = null; // Reset selected product when category changes
          this.newImage = null; // Reset new image
          this.previewImage = null; // Reset preview
        },
        error: (err) => {
          this.errorMessage = 'Error loading category products: ' + err.message;
          this.categoryproducts = [];
        }
      });
    } else {
      this.categoryproducts = [];
    }
  }

  selectproduct(product: any) {
    this.selectedproduct = { ...product };
    this.newImage = null; // Reset new image
    this.previewImage = null; // Reset preview
  }

  onImageChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.newImage = file;
      // Generate a preview URL for the new image
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.previewImage = e.target.result;
      };
      reader.readAsDataURL(file);
    } else {
      this.newImage = null;
      this.previewImage = null;
    }
  }

  onSubmit(form: NgForm) {
    if (form.valid && this.selectedproduct) {
      const formData = new FormData();
      formData.append('product_id', this.selectedproduct.product_id || '');
      formData.append('product_name', this.selectedproduct.product_name || '');
      formData.append('product_category', this.selectedproduct.product_category || '');
      formData.append('Price', this.selectedproduct.Price?.toString() || '0');
      // Include the existing Image URL if no new image is uploaded
      if (!this.newImage && this.selectedproduct.Image) {
        formData.append('Image', this.selectedproduct.Image.split('/images/')[1] || ''); // Extract filename from URL
      }
      // Include the new image file if uploaded
      if (this.newImage) {
        formData.append('Image', this.newImage);
      }

      this.http.put(`http://localhost:5000/api/products/${this.selectedproduct.product_id}`, formData, { withCredentials: true }).subscribe({
        next: (response: any) => {
          this.successMessage = 'product item updated successfully!';
          this.errorMessage = null;
          this.loadCategoryproducts(); // Refresh the list
          this.newImage = null; // Reset the new image
          this.previewImage = null; // Reset the preview
        },
        error: (err) => {
          this.errorMessage = 'Error updating product item: ' + err.message;
          this.successMessage = null;
        }
      });
    }
  }

  isValidImageUrl(url: string): boolean {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }
}