import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { productService, productItem } from '../product.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-product-search',
  standalone : false,
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class productSearchComponent implements OnInit {
  filteredproducts: productItem[] = [];
  searchTerm: string = '';
  showCart: boolean = false;
  cart: productItem[] = [];

  constructor(private route: ActivatedRoute, 
    private productService: productService,
    private authservice: AuthService
  ){}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.searchTerm = params['search'] || '';
      this.loadproducts();
      this.loadCart();
    });
  }

  logout(){
    this.authservice.logout();
  }

  loadproducts(): void {
    if (this.searchTerm.trim()) {
      this.productService.searchproducts(this.searchTerm).subscribe({
        next: (products: productItem[]) => {
          this.filteredproducts = products.map((product: productItem) => ({
            product_id: product.product_id || '',
            product_name: product.product_name || 'Unknown',
            Price: product.Price || 0,
            Image: product.Image || '/img/default.jpg',
            quantity: product.quantity || 1
          }));
        },
        error: (err: any) => {
          console.error('Search error:', err);
          this.filteredproducts = [];
          alert('Error loading search results. Please try again later.');
        }
      });
    } else {
      this.filteredproducts = [];
    }
  }

  addToCart(product: productItem): void {
    let cart: productItem[] = JSON.parse(localStorage.getItem('cart') || '[]');
    let existing = cart.find((item: productItem) => item.product_id === product.product_id);
    if (existing) {
      existing.quantity = (existing.quantity || 0) + (product.quantity || 1);
    } else {
      cart.push({ ...product, quantity: product.quantity || 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    this.loadCart();
    product.quantity = 1;
  }

  toggleCart(): void {
    this.showCart = !this.showCart;
  }

  loadCart(): void {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
  }

  removeFromCart(item: productItem): void {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
    const index = cart.findIndex((i: productItem) => i.product_id === item.product_id);
    if (index !== -1) {
      cart.splice(index, 1);
      localStorage.setItem('cart', JSON.stringify(cart));
      this.loadCart();
    }
  }

  getCartTotal(): number {
    return this.cart.reduce((sum, item) => sum + (item.Price || 0) * (item.quantity || 1), 0);
  }

  scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}