import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface productItem {
  product_id?: string;
  product_name: string;
  Price: number;
  Image: string;
  quantity?: number;
}

export interface Order {
  items: productItem[];
  deliveryDetails: {
    fullName: string;
    phoneNumber: string;
    email: string;
    address: string;
  };
  total: number;
  orderDate: string;
}

export interface OrderResponse {
  success: boolean;
  message: string;
  orderId?: string;
}

export interface UserDetails {
  name: string;
  email: string;
  phone_no: string;
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private apiUrl = 'http://localhost:5000/api';

  constructor(private http: HttpClient) {}

  submitOrder(order: Order): Observable<OrderResponse> {
    return this.http.post<OrderResponse>(`${this.apiUrl}/orders`, order, { withCredentials: true });
  }

  getUserDetails(): Observable<UserDetails> {
    return this.http.get<UserDetails>(`${this.apiUrl}/user`, { withCredentials: true });
  }
}