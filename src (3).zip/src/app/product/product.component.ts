import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService, ProductItem } from '../product.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-products',
  standalone: false,
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class productComponent implements OnInit {
  products: ProductItem[] = [];
  showCart: boolean = false;
  cart: ProductItem[] = [];
  private apiBaseUrl = 'http://localhost:5000'; // Base URL for the API

  constructor(private ProductService: ProductService,
    private authservice: AuthService
  ) {}

  ngOnInit(): void {
    this.loadCart();
    this.loadproducts();
  }

  logout(){
    this.authservice.logout();
  }

  loadproducts(): void {
    this.ProductService.getInitialproducts().subscribe({
      next: (products: ProductItem[]) => {
        if (products.length === 0) {
          console.warn('No products returned from the API.');
        } else {
          this.products = products.map((product: ProductItem) => {
            // Prepend the API base URL to the image path if it's a relative path
            const imageUrl = product.Image && !product.Image.startsWith('http')
              ? `${this.apiBaseUrl}${product.Image}`
              : product.Image || '/img/default.jpg';
            console.log(`product: ${product.product_name}, Image URL: ${imageUrl}`); // Debug log
            return {
              product_id: product.product_id || '',
              product_name: product.product_name || 'Unknown',
              Price: product.Price || 0,
              Image: imageUrl,
              quantity: product.quantity || 1
            };
          });
        }
      },
      error: (err: any) => {
        console.error('Error loading products:', err);
        alert('Error loading products. Please check the console for details.');
      },
      complete: () => {
        console.log('product loading completed. products array length:', this.products.length);
      }
    });
  }

  addToCart(product: ProductItem): void {
    let cart: ProductItem[] = JSON.parse(localStorage.getItem('cart') || '[]');
    let existing = cart.find((item: ProductItem) => item.product_id === product.product_id);
    if (existing) {
      existing.quantity = (existing.quantity || 0) + (product.quantity || 1);
    } else {
      cart.push({ ...product, quantity: product.quantity || 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    this.loadCart();
    product.quantity = 1;
  }

  toggleCart(): void {
    this.showCart = !this.showCart;
  }

  loadCart(): void {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
  }

  removeFromCart(item: ProductItem): void {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
    const index = cart.findIndex((i: ProductItem) => i.product_id === item.product_id);
    if (index !== -1) {
      cart.splice(index, 1);
      localStorage.setItem('cart', JSON.stringify(cart));
      this.loadCart();
    }
  }

  getCartTotal(): number {
    return this.cart.reduce((sum, item) => sum + (item.Price || 0) * (item.quantity || 1), 0);
  }

  scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  getproductRoute(product: ProductItem): string {
    const productName = product.product_name?.toLowerCase() || '';
    const routes: { [key: string]: string } = {
      'Flower Pots': '/FlowerPots',
      'Whistling Novalties': '/WhistlingNovalties',
      'Twinkling Star & Pencil': '/TwinklingStar&Pencil',
      'Sparklers': '/Sparklers',
      'Sound Crackers': '/SoundCrackers',
      'Set out & Gun Out': '/Setout&Gun Out',
      'Rockets': '/Rockets',
      'Repeated Shots': '/RepeatedShots',
      'Bijili': '/Bijili'
    };
    for (const key in routes) {
      if (productName.includes(key)) {
        return routes[key];
      }
    }
    return '/products';
  }
}