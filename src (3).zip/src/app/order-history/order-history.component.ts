import { Component, OnInit } from '@angular/core';
import { AdminService, Order } from '../admin.service';
import { AuthService } from '../auth.service';

interface DisplayOrder {
  order: Order;
  items: { productName: string; quantity: number }[];
  sNo: number;
}

@Component({
  selector: 'app-order-history',
  standalone: false,
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {
  displayOrders: DisplayOrder[] = [];

  constructor(private adminService: AdminService, private authservice: AuthService) {}

  ngOnInit(): void {
    this.loadOrders();
  }

  logout(){
    this.authservice.logout();
  }

  loadOrders(): void {
    this.adminService.getOrders().subscribe(orders => {
      this.displayOrders = orders.map((order, index) => ({
        order,
        items: order.items.map(item => ({
          productName: item.product_name || 'N/A',
          quantity: item.quantity || 0
        })),
        sNo: index + 1
      }));
      console.log('Loaded orders:', this.displayOrders);
    }, err => {
      console.error('Error loading orders:', err);
    });
  }
}