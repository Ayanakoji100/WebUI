import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ContactResponse {
  success: boolean;
  message: string;
  redirect?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  private apiUrl = 'http://localhost:5000/api'; // Update to use new API base URL

  constructor(private http: HttpClient) {}

  sendContactForm(name: string, email: string, phone: string, subject: string, message: string): Observable<ContactResponse> {
    return this.http.post<ContactResponse>(`${this.apiUrl}/contact`, { name, email, phone, subject, message });
  }
}