import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { OrderService, productItem, Order, UserDetails } from '../order.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-order',
  standalone: false,
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  cart: productItem[] = [];
  showCart: boolean = false;
  deliveryDetails = {
    fullName: '',
    phoneNumber: '',
    email: '',
    address: ''
  };
  successMessage: string = '';
  errorMessage: string = '';

  constructor(
    private orderService: OrderService, 
    private router: Router,
    private authservice: AuthService
  ) {}

  ngOnInit(): void {
    this.loadCart();
    this.prefillDeliveryDetails();
  }

  logout() {
    this.authservice.logout();
    this.cart = []; // Clear cart display on frontend
  }

  toggleCart(): void {
    this.showCart = !this.showCart;
  }

  loadCart(): void {
    this.cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
  }

  removeFromCart(item: productItem): void {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]') || [];
    const index = cart.findIndex((i: productItem) => i.product_id === item.product_id);
    if (index !== -1) {
      cart.splice(index, 1);
      localStorage.setItem('cart', JSON.stringify(cart));
      this.loadCart();
    }
  }

  getCartTotal(): number {
    return this.cart.reduce((sum, item) => sum + (item.Price || 0) * (item.quantity || 1), 0);
  }

  prefillDeliveryDetails(): void {
    this.orderService.getUserDetails().subscribe({
      next: (userDetails) => {
        this.deliveryDetails.fullName = userDetails.name;
        this.deliveryDetails.email = userDetails.email;
        this.deliveryDetails.phoneNumber = userDetails.phone_no;
      },
      error: (err) => {
        console.error('Error fetching user details:', err);
        this.errorMessage = 'Failed to load user details. Please fill in the form manually.';
      }
    });
  }

  onSubmit(form: NgForm): void {
    if (form.valid && this.cart.length > 0) {
      const order: Order = {
        items: this.cart,
        deliveryDetails: this.deliveryDetails,
        total: this.getCartTotal(),
        orderDate: new Date().toISOString()
      };

      this.orderService.submitOrder(order).subscribe({
        next: (response) => {
          if (response.success) {
            this.successMessage = response.message;
            this.errorMessage = '';
            localStorage.removeItem('cart'); // Clear cart after successful order
            this.cart = []; // Update frontend cart display
            form.resetForm();
            setTimeout(() => {
              this.router.navigateByUrl('/index');
            }, 1000);
          } else {
            this.errorMessage = response.message || 'Failed to place order';
            this.successMessage = '';
          }
        },
        error: (err) => {
          console.error('Order submission error:', err);
          this.errorMessage = 'An error occurred while placing the order. Please try again.';
          this.successMessage = '';
        }
      });
    } else {
      this.errorMessage = this.cart.length === 0 ? 'Your cart is empty. Please add items to place an order.' : 'Please fill in all required fields correctly';
      this.successMessage = '';
    }
  }

  scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}