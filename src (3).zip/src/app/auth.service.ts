import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';

export interface AuthResponse {
  success: boolean;
  message?: string;
  redirectUrl?: string;
  role?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:5000/api'; // API base URL

  constructor(private http: HttpClient, private router: Router) {}

  login(email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, { email, password }, { withCredentials: true }).pipe(
      map(response => {
        if (response.success && response.redirectUrl) {
          const role = response.role || (email === 'admin@packrush.com' ? 'admin' : 'user'); // Use backend role if provided, fallback to email check
          sessionStorage.setItem('user', JSON.stringify({ email, role }));
          this.router.navigate([role === 'admin' ? '/admin' : '/index']);
        }
        return response;
      })
    );
  }

  signup(name: string, email: string, phone_no: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/signup`, { name, email, phone_no, password }, { withCredentials: true });
  }

  getUser(): { email: string, role: string } | null {
    const user = JSON.parse(sessionStorage.getItem('user') || '{}');
    return user.email ? user : null;
  }

  getUserRole(): string | null {
    const user = this.getUser();
    return user ? user.role : null;
  }

  refreshUser(): void {
    const user = this.getUser();
    if (user) {
      sessionStorage.setItem('user', JSON.stringify(user)); // Ensure session is fresh
    }
  }

  logout(): void {
    this.http.post(`${this.apiUrl}/logout`, {}, { withCredentials: true }).subscribe({
      next: () => {
        sessionStorage.removeItem('user');
        localStorage.removeItem('cart');
        this.router.navigate(['/']);
      },
      error: (err) => {
        console.error('Logout error:', err);
        sessionStorage.removeItem('user');
        localStorage.removeItem('cart');
        this.router.navigate(['/']);
      }
    });
  }

  isLoggedIn(): boolean {
    return sessionStorage.getItem('user') !== null;
  }

  forceLogoutIfNotLoggedIn(): void {
    if (!this.isLoggedIn()) {
      this.router.navigate(['/']);
    }
  }
}