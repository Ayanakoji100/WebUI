import { TestBed } from '@angular/core/testing';
import { AuthGuard } from './auth.guard';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

describe('AuthGuard', () => {
  let authGuard: AuthGuard;
  let authService: jasmine.SpyObj<AuthService>;
  let router: Router;

  // Mock ActivatedRouteSnapshot and RouterStateSnapshot
  const mockActivatedRouteSnapshot = {} as ActivatedRouteSnapshot;
  const mockRouterStateSnapshot = { url: '/admin' } as RouterStateSnapshot;

  beforeEach(() => {
    // Create a spy for AuthService with isLoggedIn and getUserRole methods
    const authServiceSpy = jasmine.createSpyObj('AuthService', ['isLoggedIn', 'getUserRole']);

    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AuthGuard,
        { provide: AuthService, useValue: authServiceSpy }
      ]
    });

    authGuard = TestBed.inject(AuthGuard);
    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    router = TestBed.inject(Router);

    // Spy on router.navigate
    spyOn(router, 'navigate').and.returnValue(Promise.resolve(true));
  });

  it('should be created', () => {
    expect(authGuard).toBeTruthy();
  });

  it('should allow an authenticated user with no role requirement', () => {
    authService.isLoggedIn.and.returnValue(true);

    const result = authGuard.canActivate(mockActivatedRouteSnapshot, mockRouterStateSnapshot);
    expect(result).toBeTrue();
    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('should redirect an unauthenticated user to login', () => {
    authService.isLoggedIn.and.returnValue(false);

    const result = authGuard.canActivate(mockActivatedRouteSnapshot, mockRouterStateSnapshot);
    expect(result).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/']);
  });

  it('should allow an admin user to access an admin route', () => {
    authService.isLoggedIn.and.returnValue(true);
    authService.getUserRole.and.returnValue('admin');
    mockActivatedRouteSnapshot.data = { role: 'admin' };

    const result = authGuard.canActivate(mockActivatedRouteSnapshot, mockRouterStateSnapshot);
    expect(result).toBeTrue();
    expect(router.navigate).not.toHaveBeenCalled();
  });

  it('should redirect a non-admin user from an admin route to index', () => {
    authService.isLoggedIn.and.returnValue(true);
    authService.getUserRole.and.returnValue('user');
    mockActivatedRouteSnapshot.data = { role: 'admin' };

    const result = authGuard.canActivate(mockActivatedRouteSnapshot, mockRouterStateSnapshot);
    expect(result).toBeFalse();
    expect(router.navigate).toHaveBeenCalledWith(['/index']);
  });
});