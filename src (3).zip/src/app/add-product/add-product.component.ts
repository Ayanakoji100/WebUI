import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-add-product',
  standalone: false,
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddproductComponent {
  productItem = { product_id: '', product_name: '', product_category: '', Price: 0, Image: '' };
  successMessage: string | null = null;
  errorMessage: string | null = null;
  categories = ['Flower Pots', 'Gift Boxes', 'Repeated Shots', 'Set out & Gun Out', 'Sound Crackers', 'Sparklers', 'Twinkling Star & Pencil', 'Whistling Novalties', 'Bijili'];
  imageFile: File | null = null; // Store the uploaded image file
  previewImage: string | null = null; // Store the preview URL for the uploaded image

  constructor(private http: HttpClient, private authservice: AuthService) {}
    
    logout(){
      this.authservice.logout();
    }

  onImageChange(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.imageFile = file;
      // Generate a preview URL for the uploaded image
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.previewImage = e.target.result;
      };
      reader.readAsDataURL(file);
    } else {
      this.imageFile = null;
      this.previewImage = null;
    }
  }

  onSubmit(form: NgForm) {
    if (form.valid && this.imageFile) {
      const formData = new FormData();
      formData.append('product_id', this.productItem.product_id || '');
      formData.append('product_name', this.productItem.product_name || '');
      formData.append('product_category', this.productItem.product_category || '');
      formData.append('Price', this.productItem.Price?.toString() || '0');
      formData.append('Image', this.imageFile);

      this.http.post('http://localhost:5000/api/products', formData, { withCredentials: true }).subscribe({
        next: (response: any) => {
          this.successMessage = 'product item added successfully!';
          this.errorMessage = null;
          this.productItem = { product_id: '', product_name: '', product_category: '', Price: 0, Image: '' }; // Reset form
          this.imageFile = null; // Reset the image file
          this.previewImage = null; // Reset the preview
          form.resetForm();
        },
        error: (err) => {
          this.errorMessage = 'Error adding product item: ' + err.message;
          this.successMessage = null;
        }
      });
    } else {
      this.errorMessage = 'Please fill all required fields and upload an image.';
      this.successMessage = null;
    }
  }
}