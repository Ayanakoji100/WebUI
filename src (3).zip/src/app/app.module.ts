import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IndexComponent } from './index/index.component';
import { ContactComponent } from './contact/contact.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { productComponent } from './product/product.component';
import { productSearchComponent } from './product-search/product-search.component';
import { OrderComponent } from './order/order.component';
import { AdminComponent } from './admin/admin.component';
import { AddproductComponent } from './add-product/add-product.component';
import { UpdateproductComponent } from './update-product/update-product.component';
import { DeleteproductComponent } from './delete-product/delete-product.component';
import { ManageReviewComponent } from './manage-review/manage-review.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { CategoryComponent } from './category/category.component';

@NgModule({
  declarations: [
    AppComponent,
    IndexComponent,
    ContactComponent,
    LoginComponent,
    SignupComponent,
    productComponent,
    OrderComponent,
    productSearchComponent,
    AdminComponent,
    AddproductComponent,
    UpdateproductComponent,
    DeleteproductComponent,
    ManageReviewComponent,
    OrderHistoryComponent,
    CategoryComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    CommonModule,
    FormsModule,
    RouterModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }