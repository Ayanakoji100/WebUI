import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface productItem {
  _id?: string;
  product_id?: string;
  product_name: string;
  product_category?: string;
  Price: number;
  Image: string;
  quantity?: number;
}

export interface Order {
  _id?: string;
  items: { product_name: string; Price: number; Image: string; quantity: number }[];
  deliveryDetails: { fullName: string; phoneNumber: string; email: string; address: string };
  total?: number;
  orderDate: string;
  userEmail: string;
  createdAt: string;
}

export interface Review {
  _id?: string;
  customer?: string;
  phone? : string,
  subject? : string,
  comment?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = 'http://localhost:5000/api';

  constructor(private http: HttpClient) {}

  getproductItems(): Observable<productItem[]> {
    return this.http.get<productItem[]>(`${this.apiUrl}/products`);
  }

  getproductItemsByCategory(category: string): Observable<productItem[]> {
    return this.http.get<productItem[]>(`${this.apiUrl}/products/category/${category}`);
  }

  addproductItem(product: productItem): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/products`, product);
  }

  updateproductItem(id: string, updatedproduct: Partial<productItem>): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/products/${id}`, updatedproduct);
  }

  deleteproductItem(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/products/${id}`);
  }

  getOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(`${this.apiUrl}/admin/orders`);
  }

  getReviews(): Observable<Review[]> {
    return this.http.get<Review[]>(`${this.apiUrl}/customer_reviews`);
  }
}