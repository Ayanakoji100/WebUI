import { Component } from '@angular/core';
import { AuthService, AuthResponse } from '../auth.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  formData = {
    email: '',
    password: ''
  };
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit(form: NgForm): void {
    if (form.valid) {
      this.authService.login(this.formData.email, this.formData.password).subscribe({
        next: (response: AuthResponse) => {
          if (response.success) {
            this.successMessage = response.message || 'Login successful! Redirecting...';
            this.errorMessage = '';
            form.resetForm();

            // Check if the user is an admin
            const isAdmin = this.formData.email === 'admin@packrush.com'; // Admin email check
            const redirectUrl = isAdmin ? '/admin' : (response.redirectUrl || '/index');
          } else {
            this.errorMessage = response.message || 'Login failed';
            this.successMessage = '';
          }
        },
        error: (err) => {
          console.error('Login error:', err);
          this.errorMessage = 'An error occurred during login. Please try again.';
          this.successMessage = '';
        }
      });
    } else {
      this.errorMessage = 'Please fill in all required fields correctly';
      this.successMessage = '';
    }
  }

  /*isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }*/
}