import { Component, OnInit } from '@angular/core';
import { AdminService, Review } from '../admin.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-manage-review',
  standalone: false,
  templateUrl: './manage-review.component.html',
  styleUrls: ['./manage-review.component.css']
})
export class ManageReviewComponent implements OnInit {
  reviews: Review[] = [];

  constructor(private adminService: AdminService, private authservice: AuthService) {}

  ngOnInit(): void {
    this.loadReviews();
  }

  logout(){
    this.authservice.logout();
  }
  loadReviews(): void {
    this.adminService.getReviews().subscribe(reviews => {
      this.reviews = reviews.map(review => ({
        _id: review._id || '',
        customer: review.customer || 'N/A',
        phone : review.phone || 'N/A',
        subject : review.subject || 'N/A',
        comment: review.comment || 'No comment'
      }));
      console.log('Loaded reviews:', this.reviews); // Debug log
    }, err => {
      console.error('Error loading reviews:', err);
    });
  }
}