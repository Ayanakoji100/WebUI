import { Component, OnInit } from '@angular/core';
import { AuthService, AuthResponse } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  standalone: false,
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  formData = {
    name: '',
    email: '',
    phone_no: '',
    password: '',
    confirmPassword: ''
  };
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.formData.password !== this.formData.confirmPassword) {
      this.errorMessage = 'Passwords do not match.';
      this.successMessage = '';
      return;
    }

    this.authService.signup(
      this.formData.name,
      this.formData.email,
      this.formData.phone_no,
      this.formData.password
    ).subscribe({
      next: (response: AuthResponse) => {
        if (response.success) {
          this.successMessage = response.message || 'Signup successful! Please log in.';
          this.errorMessage = '';
          this.formData = { name: '', email: '', phone_no: '', password: '', confirmPassword: '' };
          setTimeout(() => {
            this.router.navigateByUrl('/index');
          }, 1000);
        } else {
          this.errorMessage = response.message || 'Signup failed. Please try again.';
          this.successMessage = '';
        }
      },
      error: (err: any) => {
        this.errorMessage = 'An error occurred. Please try again later.';
        this.successMessage = '';
        console.error('Signup error:', err);
      }
    });
  }

  scrollToTop(): void {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}