import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ProductItem {
  _id?: string;
  product_id?: string;
  product_name: string;
  product_category?: string;
  Price: number;
  Image: string;
  quantity?: number;
}

export interface Order {
  _id?: string;
  items?: string[];
  deliveryDetails?: { fullName: string; phoneNumber: string; email: string; address: string };
  total?: number;
  orderDate?: string;
  userEmail?: string;
  createdAt?: string;
}

export interface Review {
  _id?: string;
  customer?: string;
  product?: string;
  rating?: number;
  comment?: string;
  date?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = 'http://localhost:5000/api'; // Update to use new API base URL

  constructor(private http: HttpClient) {}

  // Existing method - unchanged
  searchproducts(searchTerm: string): Observable<ProductItem[]> {
    return this.http.get<ProductItem[]>(`${this.apiUrl}/search?q=${encodeURIComponent(searchTerm)}`);
  }

  // Existing method - unchanged
  getInitialproducts(): Observable<ProductItem[]> {
    return this.http.get<ProductItem[]>(`${this.apiUrl}/products`);
  }

  // User-facing method for placing an order
  placeOrder(order: Order): Observable<{ success: boolean; message: string; orderId?: string }> {
    return this.http.post<{ success: boolean; message: string; orderId?: string }>(`${this.apiUrl}/orders`, order);
  }

  // Method for fetching product items by category (used by CategoryComponent)
  getproductItemsByCategory(category: string): Observable<ProductItem[]> {
    return this.http.get<ProductItem[]>(`${this.apiUrl}/products/category/${category}`);
  }
}