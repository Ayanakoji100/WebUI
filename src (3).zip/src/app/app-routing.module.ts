import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { IndexComponent } from './index/index.component';
import { ContactComponent } from './contact/contact.component';
import { LoginComponent } from './login/login.component';
import { productSearchComponent } from './product-search/product-search.component';
import { SignupComponent } from './signup/signup.component';
import { productComponent } from './product/product.component';
import { OrderComponent } from './order/order.component';
import { AdminComponent } from './admin/admin.component';
import { AddproductComponent } from './add-product/add-product.component';
import { UpdateproductComponent } from './update-product/update-product.component';
import { DeleteproductComponent } from './delete-product/delete-product.component';
import { ManageReviewComponent } from './manage-review/manage-review.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { CategoryComponent } from './category/category.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'index', component: IndexComponent, canActivate: [AuthGuard] },
  { path: 'products', component: productComponent, canActivate: [AuthGuard] },
  { path: 'order', component: OrderComponent, canActivate: [AuthGuard] },
  { path: 'contact', component: ContactComponent, canActivate: [AuthGuard] },
  { path: 'signup', component: SignupComponent },
  { path: 'product-search', component: productSearchComponent, canActivate: [AuthGuard] },
  { path: 'category/:category', component: CategoryComponent, canActivate: [AuthGuard] },
  { path: 'admin', component: AdminComponent, canActivate: [AuthGuard], data: { role: 'admin' } },
  { path: 'add-product', component: AddproductComponent, canActivate: [AuthGuard], data: { role: 'admin' } },
  { path: 'update-product', component: UpdateproductComponent, canActivate: [AuthGuard], data: { role: 'admin' } },
  { path: 'delete-product', component: DeleteproductComponent, canActivate: [AuthGuard], data: { role: 'admin' } },
  { path: 'manage-review', component: ManageReviewComponent, canActivate: [AuthGuard], data: { role: 'admin' } },
  { path: 'order-history', component: OrderHistoryComponent, canActivate: [AuthGuard], data: { role: 'admin' } },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }